from ..de_CH import Provider as DeChBankProvider


class Provider(DeChBankProvider):
    """Implement bank provider for ``it_CH`` locale.

    There is no difference from the ``de_CH`` implementation.
    """
    pass
